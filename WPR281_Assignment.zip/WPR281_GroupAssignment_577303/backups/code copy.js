
function redlighGreenlight(ID,pattern,classs) {
 
    
        // Validation for Last Name (letters only)
        var NameInput = document.getElementById(ID);
        var NameValue = NameInput.value.trim();

        var Label = document.getElementsByClassName(classs)[0]
      
    
        var namePattern = pattern;
    
    
        if (!namePattern.test(NameValue) && classs === ID) {
          // Display error message or visual effect for invalid input
          
         
          submitOK = 'false' 
          
        // changes the colour for label and border
          NameInput.style.borderBottom = "2px"
          NameInput.style.borderBottomStyle = "solid"
          NameInput.style.borderBottomColor = "red"

          Label.style.color = "red"
        } else {
    
            NameInput.style.borderBottom = "2px"
            NameInput.style.borderBottomStyle = "solid"
            NameInput.style.borderBottomColor = "green"
    
            Label.style.color = "green"
          }
}

function validateForm() {


    submitOK = 'true'

  






  
    // Validation for Country (at least three options)
    var countryInput = document.getElementById("country");
    var selectedCountry = countryInput.value;
  
    if (selectedCountry === "") {
      // Display error message or visual effect for invalid input
      alert("Please select a valid Country.");
      countryInput.focus();
      submitOK = 'false' 
    
      countryInput.style.border = "2px"
      countryInput.style.borderStyle = "solid"
      countryInput.style.borderColor = "red"
    }
  



    // Validation for Gender (at least three options)
    var stateInput = document.getElementById("state");
    var selectedState = stateInput.value;

  
    if (selectedState === "") {
      // Display error message or visual effect for invalid input
      alert("Please select a valid Gender.");
      stateInput.focus();
      submitOK = 'false';
    }
  
    
    // Validation for Phone Number (xxx-xxxx format)
    var phoneNumberInput = document.getElementById("phoneNumber");
    var phoneNumberValue = phoneNumberInput.value.trim();
    var phonePattern = /^\d{3}-\d{4}$/;
  
    if (!phonePattern.test(phoneNumberValue)) {
      // Display error message or visual effect for invalid input
      alert("Phone Number must be in the format xxx-xxxx.");
      phoneNumberInput.focus();
      submitOK = 'false' 
    
      phoneNumberInput.style.border = "2px"
      phoneNumberInput.style.borderStyle = "solid"
      phoneNumberInput.style.borderColor = "red"
    }

  




    // If all validations pass, hide the form and display the summary
   // document.getElementById("registrationForm").style.display = "none";
    document.getElementById("summary").style.display = "block";
  
    // Code to display the summary of entered information
    // make it more interactive, changing color onece info has been validated and accepted
    // please replace gender with state
    
    if (submitOK == 'false') {
      
      return false; // Prevent form submission (since we are showing the summary instead)

    } else{

    }
    



  }
  
  document.getElementById("firstName").addEventListener("blur", function(){
  redlighGreenlight("firstName",/^[A-Za-z]+$/,"firstName")
  })


//   document.getElementById("firstName").addEventListener("blur", function(){


//        // Validation for First Name (letters only)
//        var firstNameInput = document.getElementById("firstName");
//        var firstNameValue = firstNameInput.value;
//        firstNameValue = firstNameValue.trim()
   
//        var namePattern = /^[A-Za-z]+$/;

       
//     if (!namePattern.test(firstNameValue)) {
//       // Display error message or visual effect for invalid input
//       //("First Name must contain letters only.");
//       submitOK = 'false';

//       firstNameInput.style.border = "2px"
//       firstNameInput.style.borderStyle = "solid"
//       firstNameInput.style.borderColor = "red"

      

//         } else {

//           firstNameInput.style.border = "2px"
//           firstNameInput.style.borderStyle = "solid"
//           firstNameInput.style.borderColor = "green"

//         }
//   })

  document.getElementById("lastName").addEventListener("blur", function(){

    
    redlighGreenlight("lastName",/^[A-Za-z]+$/,"lastName")


    // // Validation for Last Name (letters only)
    // var lastNameInput = document.getElementById("lastName");
    // var lastNameValue = lastNameInput.value.trim();
  

    // var namePattern = /^[A-Za-z]+$/;


    // if (!namePattern.test(lastNameValue)) {
    //   // Display error message or visual effect for invalid input
    //   alert("Last Name must contain letters only.");
     
    //   submitOK = 'false' 
      
    
    //   lastNameInput.style.border = "2px"
    //   lastNameInput.style.borderStyle = "solid"
    //   lastNameInput.style.borderColor = "red"
    // } else {

    //     lastNameInput.style.border = "2px"
    //     lastNameInput.style.borderStyle = "solid"
    //     lastNameInput.style.borderColor = "green"

    //   }
  
  })

  document.getElementById("email").addEventListener("blur", function(){

    
    redlighGreenlight("email", /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,"email")
  })