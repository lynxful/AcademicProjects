
function redlighGreenlight(ID,pattern,classs) {
 
    
        // Validation 
        var NameInput = document.getElementById(ID);
        var NameValue = NameInput.value.trim();

        var Label = document.getElementsByClassName(classs)[0]
      
    
        var namePattern = pattern;
    
    
        if (!namePattern.test(NameValue) && classs === ID) {
          // Display error message or visual effect for invalid input
          
         
          submitOK = 'false' 
          
         // changes the colour for label and border
          NameInput.style.borderBottom = "2px"
          NameInput.style.borderBottomStyle = "solid"
          NameInput.style.borderBottomColor = "red"

          Label.style.color = "red"

          return false
        } else {
    
            NameInput.style.borderBottom = "2px"
            NameInput.style.borderBottomStyle = "solid"
            NameInput.style.borderBottomColor = "green"
    
            Label.style.color = "green"

            submitOK = 'true' 
            return true
            
          }
}


function noPattern(ID, classs) {

        // Validation (no validation pattern)
        var NameInput = document.getElementById(ID);
        var NameValue = NameInput.value.trim();

        var Label = document.getElementsByClassName(classs)[0]
      
    
    
        if (NameValue == "" && classs === ID) {
          // Display error message or visual effect for invalid input
          
         
          submitOK = 'false' 
          
        // changes the colour for label and border depending on input
          NameInput.style.borderBottom = "2px"
          NameInput.style.borderBottomStyle = "solid"
          NameInput.style.borderBottomColor = "red"

          Label.style.color = "red"

          return false
        } else {
    
            NameInput.style.borderBottom = "2px"
            NameInput.style.borderBottomStyle = "solid"
            NameInput.style.borderBottomColor = "green"
    
            Label.style.color = "green"

            submitOK = 'true' 

            return true
          }
  
}

function getData() {


  //getting data from fields and displaying it in html
  var firstName = document.getElementById("firstName").value
  var lastName = document.getElementById("lastName").value
  var email = document.getElementById("email").value
  var userID = document.getElementById("userID").value
  var country = document.getElementById("country").value
  var state = document.getElementById("state").value
  var city = document.getElementById("city").value
  var phoneNumber = document.getElementById("phoneNumber").value
  var referenceCode = document.getElementById("referenceCode").value
  
  document.getElementsByClassName("firstName")[1].innerHTML = firstName
  document.getElementsByClassName("lastName")[1] = lastName
  document.getElementsByClassName("email")[1].innerHTML = email
  document.getElementsByClassName("userID")[1].innerHTML = userID
  document.getElementsByClassName("country")[1].innerHTML = country
  document.getElementsByClassName("state")[1].innerHTML = state
  document.getElementsByClassName("city")[1].innerHTML = city
  document.getElementsByClassName("phoneNumber")[1].innerHTML = phoneNumber
  document.getElementsByClassName("referenceCode")[1].innerHTML = referenceCode



}


function validateForm() {


    


    // If all validations pass, hide the form and display the summary
   
   
  
    // Code to display the summary of entered information
    // make it more interactive, changing color onece info has been validated and accepted
    // please replace gender with state
    
    if (validCheck.includes(false) == true) {
      
      alert("This form cannot be submitted")
      return false; // Prevent form submission (since we are showing the summary instead)

    } else{
      document.getElementById("registrationForm").style.display = "none";

      alert("you have done it")
      document.getElementById("summary").style.display = "block";

      //displaying summary function
      getData()
    
      

      return false
    }
    


}

//havent figured out how to check if every field is green lit
// few hours after writing that i figured it out, made a valid check array that
//makes sure every field is green lit before sending 
  let validCheck = []
  
  submitOK = 'true'

  document.getElementById("firstName").addEventListener("blur", function(){

  validCheck[0] = ( redlighGreenlight("firstName",/^[A-Za-z]+$/,"firstName"))

  })



  document.getElementById("lastName").addEventListener("blur", function(){

    
    validCheck[1] = (redlighGreenlight("lastName",/^[A-Za-z]+$/,"lastName"))

  
  })

  document.getElementById("email").addEventListener("blur", function(){

    
    validCheck[2] = redlighGreenlight("email", /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,"email")
  })
     
  document.getElementById("userID").addEventListener("blur", function(){

    
    validCheck[3] = redlighGreenlight("userID",/[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]/,"userID")

  })
      
  document.getElementById("country").addEventListener("blur", function(){

    
    validCheck[4] = noPattern("country","country")

  })
      
  document.getElementById("state").addEventListener("blur", function(){

    
    validCheck[5] = noPattern("state","state")

  })
      
  document.getElementById("city").addEventListener("blur", function(){

    
    validCheck[6] = noPattern("city","city")

  })
  
  document.getElementById("phoneNumber").addEventListener("blur", function(){

    
    validCheck[7] = redlighGreenlight("phoneNumber",/^\d{3}-\d{4}$/,"phoneNumber")

  })
 
    
  document.getElementById("referenceCode").addEventListener("blur", function(){

    
    validCheck[8] = redlighGreenlight("referenceCode",/[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]/,"referenceCode")

  })
  