﻿namespace Fuller_Lynnette_PRG2781_ST
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHeader = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnFullTime = new System.Windows.Forms.Button();
            this.btnPartTime = new System.Windows.Forms.Button();
            this.btnAll = new System.Windows.Forms.Button();
            this.lblDisplayBtns = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnLast = new System.Windows.Forms.Button();
            this.lblNav = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtStudentNumber = new System.Windows.Forms.TextBox();
            this.lblInput = new System.Windows.Forms.Label();
            this.lblSearch = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblPayment = new System.Windows.Forms.Label();
            this.lblFees = new System.Windows.Forms.Label();
            this.lblResults = new System.Windows.Forms.Label();
            this.lblMark = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblStudentDetails = new System.Windows.Forms.Label();
            this.lblLabelPayment = new System.Windows.Forms.Label();
            this.lblLabelFees = new System.Windows.Forms.Label();
            this.lblLabelResults = new System.Windows.Forms.Label();
            this.lblLabelMark = new System.Windows.Forms.Label();
            this.lblLabelName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Times New Roman", 24.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(109, 19);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(428, 37);
            this.lblHeader.TabIndex = 0;
            this.lblHeader.Text = "STUDENT MARKS SYSTEM";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(26, 79);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(617, 218);
            this.dataGridView1.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Bisque;
            this.panel1.Controls.Add(this.btnFullTime);
            this.panel1.Controls.Add(this.btnPartTime);
            this.panel1.Controls.Add(this.btnAll);
            this.panel1.Controls.Add(this.lblDisplayBtns);
            this.panel1.Location = new System.Drawing.Point(667, 79);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 218);
            this.panel1.TabIndex = 2;
            // 
            // btnFullTime
            // 
            this.btnFullTime.BackColor = System.Drawing.Color.Bisque;
            this.btnFullTime.FlatAppearance.BorderColor = System.Drawing.Color.Sienna;
            this.btnFullTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFullTime.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFullTime.ForeColor = System.Drawing.Color.Black;
            this.btnFullTime.Location = new System.Drawing.Point(18, 160);
            this.btnFullTime.Name = "btnFullTime";
            this.btnFullTime.Size = new System.Drawing.Size(169, 43);
            this.btnFullTime.TabIndex = 3;
            this.btnFullTime.Text = "View Full-Time Students";
            this.btnFullTime.UseVisualStyleBackColor = true;
            this.btnFullTime.Click += new System.EventHandler(this.btnFullTime_Click);
            // 
            // btnPartTime
            // 
            this.btnPartTime.BackColor = System.Drawing.Color.Bisque;
            this.btnPartTime.FlatAppearance.BorderColor = System.Drawing.Color.Sienna;
            this.btnPartTime.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPartTime.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPartTime.ForeColor = System.Drawing.Color.Black;
            this.btnPartTime.Location = new System.Drawing.Point(18, 100);
            this.btnPartTime.Name = "btnPartTime";
            this.btnPartTime.Size = new System.Drawing.Size(169, 43);
            this.btnPartTime.TabIndex = 2;
            this.btnPartTime.Text = "View Part-Time Students";
            this.btnPartTime.UseVisualStyleBackColor = true;
            this.btnPartTime.Click += new System.EventHandler(this.btnPartTime_Click);
            // 
            // btnAll
            // 
            this.btnAll.BackColor = System.Drawing.Color.Bisque;
            this.btnAll.FlatAppearance.BorderColor = System.Drawing.Color.Sienna;
            this.btnAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAll.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAll.ForeColor = System.Drawing.Color.Black;
            this.btnAll.Location = new System.Drawing.Point(18, 39);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(169, 43);
            this.btnAll.TabIndex = 1;
            this.btnAll.Text = "View All Students";
            this.btnAll.UseVisualStyleBackColor = false;
            // 
            // lblDisplayBtns
            // 
            this.lblDisplayBtns.AutoSize = true;
            this.lblDisplayBtns.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDisplayBtns.ForeColor = System.Drawing.Color.Coral;
            this.lblDisplayBtns.Location = new System.Drawing.Point(3, 10);
            this.lblDisplayBtns.Name = "lblDisplayBtns";
            this.lblDisplayBtns.Size = new System.Drawing.Size(80, 13);
            this.lblDisplayBtns.TabIndex = 0;
            this.lblDisplayBtns.Text = "Display Buttons";
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.Tomato;
            this.btnExit.Location = new System.Drawing.Point(667, 22);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(200, 42);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Bisque;
            this.panel2.Controls.Add(this.btnFirst);
            this.panel2.Controls.Add(this.btnNext);
            this.panel2.Controls.Add(this.btnPrevious);
            this.panel2.Controls.Add(this.btnLast);
            this.panel2.Controls.Add(this.lblNav);
            this.panel2.Location = new System.Drawing.Point(26, 313);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(617, 100);
            this.panel2.TabIndex = 4;
            // 
            // btnFirst
            // 
            this.btnFirst.BackColor = System.Drawing.Color.Linen;
            this.btnFirst.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnFirst.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFirst.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFirst.ForeColor = System.Drawing.Color.Blue;
            this.btnFirst.Location = new System.Drawing.Point(478, 39);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(103, 34);
            this.btnFirst.TabIndex = 4;
            this.btnFirst.Text = ">|";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.Linen;
            this.btnNext.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.ForeColor = System.Drawing.Color.Blue;
            this.btnNext.Location = new System.Drawing.Point(328, 39);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(103, 34);
            this.btnNext.TabIndex = 3;
            this.btnNext.Text = ">>";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.BackColor = System.Drawing.Color.Linen;
            this.btnPrevious.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnPrevious.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrevious.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrevious.ForeColor = System.Drawing.Color.Blue;
            this.btnPrevious.Location = new System.Drawing.Point(181, 39);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(103, 34);
            this.btnPrevious.TabIndex = 2;
            this.btnPrevious.Text = "<<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnLast
            // 
            this.btnLast.BackColor = System.Drawing.Color.Linen;
            this.btnLast.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnLast.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLast.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLast.ForeColor = System.Drawing.Color.Blue;
            this.btnLast.Location = new System.Drawing.Point(37, 39);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(103, 34);
            this.btnLast.TabIndex = 1;
            this.btnLast.Text = "|<";
            this.btnLast.UseVisualStyleBackColor = false;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // lblNav
            // 
            this.lblNav.AutoSize = true;
            this.lblNav.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNav.ForeColor = System.Drawing.Color.Coral;
            this.lblNav.Location = new System.Drawing.Point(4, 4);
            this.lblNav.Name = "lblNav";
            this.lblNav.Size = new System.Drawing.Size(63, 13);
            this.lblNav.TabIndex = 0;
            this.lblNav.Text = "Navigations";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Bisque;
            this.panel3.Controls.Add(this.btnSearch);
            this.panel3.Controls.Add(this.txtStudentNumber);
            this.panel3.Controls.Add(this.lblInput);
            this.panel3.Controls.Add(this.lblSearch);
            this.panel3.Location = new System.Drawing.Point(667, 313);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 100);
            this.panel3.TabIndex = 5;
            // 
            // btnSearch
            // 
            this.btnSearch.ForeColor = System.Drawing.Color.Blue;
            this.btnSearch.Location = new System.Drawing.Point(9, 71);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(178, 23);
            this.btnSearch.TabIndex = 3;
            this.btnSearch.Text = "Search Student";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtStudentNumber
            // 
            this.txtStudentNumber.Location = new System.Drawing.Point(9, 44);
            this.txtStudentNumber.Name = "txtStudentNumber";
            this.txtStudentNumber.Size = new System.Drawing.Size(178, 20);
            this.txtStudentNumber.TabIndex = 2;
            // 
            // lblInput
            // 
            this.lblInput.AutoSize = true;
            this.lblInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInput.ForeColor = System.Drawing.Color.Blue;
            this.lblInput.Location = new System.Drawing.Point(33, 26);
            this.lblInput.Name = "lblInput";
            this.lblInput.Size = new System.Drawing.Size(129, 15);
            this.lblInput.TabIndex = 1;
            this.lblInput.Text = "Enter Student Number";
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.ForeColor = System.Drawing.Color.Coral;
            this.lblSearch.Location = new System.Drawing.Point(6, 4);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(81, 13);
            this.lblSearch.TabIndex = 0;
            this.lblSearch.Text = "Search Student";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Bisque;
            this.panel4.Controls.Add(this.lblPayment);
            this.panel4.Controls.Add(this.lblFees);
            this.panel4.Controls.Add(this.lblResults);
            this.panel4.Controls.Add(this.lblMark);
            this.panel4.Controls.Add(this.lblName);
            this.panel4.Controls.Add(this.lblStudentDetails);
            this.panel4.Controls.Add(this.lblLabelPayment);
            this.panel4.Controls.Add(this.lblLabelFees);
            this.panel4.Controls.Add(this.lblLabelResults);
            this.panel4.Controls.Add(this.lblLabelMark);
            this.panel4.Controls.Add(this.lblLabelName);
            this.panel4.Location = new System.Drawing.Point(26, 430);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(841, 100);
            this.panel4.TabIndex = 6;
            // 
            // lblPayment
            // 
            this.lblPayment.AutoSize = true;
            this.lblPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPayment.ForeColor = System.Drawing.Color.Maroon;
            this.lblPayment.Location = new System.Drawing.Point(718, 62);
            this.lblPayment.Name = "lblPayment";
            this.lblPayment.Size = new System.Drawing.Size(55, 13);
            this.lblPayment.TabIndex = 10;
            this.lblPayment.Text = "Payment";
            // 
            // lblFees
            // 
            this.lblFees.AutoSize = true;
            this.lblFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFees.ForeColor = System.Drawing.Color.Maroon;
            this.lblFees.Location = new System.Drawing.Point(547, 62);
            this.lblFees.Name = "lblFees";
            this.lblFees.Size = new System.Drawing.Size(34, 13);
            this.lblFees.TabIndex = 9;
            this.lblFees.Text = "Fees";
            // 
            // lblResults
            // 
            this.lblResults.AutoSize = true;
            this.lblResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResults.ForeColor = System.Drawing.Color.Maroon;
            this.lblResults.Location = new System.Drawing.Point(344, 62);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(49, 13);
            this.lblResults.TabIndex = 8;
            this.lblResults.Text = "Results";
            // 
            // lblMark
            // 
            this.lblMark.AutoSize = true;
            this.lblMark.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMark.ForeColor = System.Drawing.Color.Maroon;
            this.lblMark.Location = new System.Drawing.Point(202, 62);
            this.lblMark.Name = "lblMark";
            this.lblMark.Size = new System.Drawing.Size(35, 13);
            this.lblMark.TabIndex = 7;
            this.lblMark.Text = "Mark";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.Maroon;
            this.lblName.Location = new System.Drawing.Point(37, 62);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(87, 13);
            this.lblName.TabIndex = 6;
            this.lblName.Text = "Student Name";
            // 
            // lblStudentDetails
            // 
            this.lblStudentDetails.AutoSize = true;
            this.lblStudentDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudentDetails.ForeColor = System.Drawing.Color.Coral;
            this.lblStudentDetails.Location = new System.Drawing.Point(7, 4);
            this.lblStudentDetails.Name = "lblStudentDetails";
            this.lblStudentDetails.Size = new System.Drawing.Size(79, 13);
            this.lblStudentDetails.TabIndex = 5;
            this.lblStudentDetails.Text = "Student Details";
            // 
            // lblLabelPayment
            // 
            this.lblLabelPayment.AutoSize = true;
            this.lblLabelPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLabelPayment.ForeColor = System.Drawing.Color.Blue;
            this.lblLabelPayment.Location = new System.Drawing.Point(718, 36);
            this.lblLabelPayment.Name = "lblLabelPayment";
            this.lblLabelPayment.Size = new System.Drawing.Size(48, 13);
            this.lblLabelPayment.TabIndex = 4;
            this.lblLabelPayment.Text = "Payment";
            // 
            // lblLabelFees
            // 
            this.lblLabelFees.AutoSize = true;
            this.lblLabelFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLabelFees.ForeColor = System.Drawing.Color.Blue;
            this.lblLabelFees.Location = new System.Drawing.Point(547, 36);
            this.lblLabelFees.Name = "lblLabelFees";
            this.lblLabelFees.Size = new System.Drawing.Size(30, 13);
            this.lblLabelFees.TabIndex = 3;
            this.lblLabelFees.Text = "Fees";
            // 
            // lblLabelResults
            // 
            this.lblLabelResults.AutoSize = true;
            this.lblLabelResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLabelResults.ForeColor = System.Drawing.Color.Blue;
            this.lblLabelResults.Location = new System.Drawing.Point(344, 36);
            this.lblLabelResults.Name = "lblLabelResults";
            this.lblLabelResults.Size = new System.Drawing.Size(42, 13);
            this.lblLabelResults.TabIndex = 2;
            this.lblLabelResults.Text = "Results";
            // 
            // lblLabelMark
            // 
            this.lblLabelMark.AutoSize = true;
            this.lblLabelMark.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLabelMark.ForeColor = System.Drawing.Color.Blue;
            this.lblLabelMark.Location = new System.Drawing.Point(202, 36);
            this.lblLabelMark.Name = "lblLabelMark";
            this.lblLabelMark.Size = new System.Drawing.Size(31, 13);
            this.lblLabelMark.TabIndex = 1;
            this.lblLabelMark.Text = "Mark";
            // 
            // lblLabelName
            // 
            this.lblLabelName.AutoSize = true;
            this.lblLabelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLabelName.ForeColor = System.Drawing.Color.Blue;
            this.lblLabelName.Location = new System.Drawing.Point(34, 36);
            this.lblLabelName.Name = "lblLabelName";
            this.lblLabelName.Size = new System.Drawing.Size(75, 13);
            this.lblLabelName.TabIndex = 0;
            this.lblLabelName.Text = "Student Name";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(907, 542);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblHeader);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnFullTime;
        private System.Windows.Forms.Button btnPartTime;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Label lblDisplayBtns;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Label lblNav;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtStudentNumber;
        private System.Windows.Forms.Label lblInput;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblPayment;
        private System.Windows.Forms.Label lblFees;
        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.Label lblMark;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblStudentDetails;
        private System.Windows.Forms.Label lblLabelPayment;
        private System.Windows.Forms.Label lblLabelFees;
        private System.Windows.Forms.Label lblLabelResults;
        private System.Windows.Forms.Label lblLabelMark;
        private System.Windows.Forms.Label lblLabelName;
    }
}

