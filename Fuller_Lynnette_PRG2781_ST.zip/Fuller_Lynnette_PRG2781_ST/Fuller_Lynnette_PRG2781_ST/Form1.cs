﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fuller_Lynnette_PRG2781_ST
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        DataTable myTable = new DataTable();

        private void Form1_Load(object sender, EventArgs e)
        {
           

            myTable.Columns.Add("StudNumber", typeof(int));
            myTable.Columns.Add("StudName", typeof(string));
            myTable.Columns.Add("Average", typeof(int));
            myTable.Columns.Add("Results", typeof(string));
            myTable.Columns.Add("Fees", typeof(double));
            myTable.Columns.Add("Payment", typeof(double));

            myTable.Rows.Add(573303, "Lyn",80, /*checkResults(80)*/ "Pass", 25000, 15000);

            //DataHandler dataHandler = new DataHandler();
            //myTable.Rows.Add(dataHandler.allStudents);

            dataGridView1.DataSource = myTable;
        }

        //Declare delegate
        public delegate string CheckResults(double avg);
        public event CheckResults checkEvent;
        public List<Students> allStudents = new List<Students>();

        class DataHandler
        {
            /*
             public List<Students> allStudents = new List<Students>()
             {
                 new PartTime(577303,"Lynnette Fuller","PartTime",80,"Passed",25000,23000)
             };
             */

            public string checkEvent(double avg)
            {
                string results;

                if(avg < 50)
                {
                    results = "fail";
                } else if(avg <= 75)
                {
                    results = "pass";
                }else if(avg <= 100)
                {
                    results = "passed with distinction";
                }
                else
                {
                    results = "invalid result";
                }

                return results;
            }
/*
            public string CheckResults(double avg)
            {
                if(checkEvent != null)
                {
                    checkEvent();
                }
            }
*/
        }

        //Create abstract class - "Students"
        public abstract class Students
        {
            /*
             * Add relevant fields and properties as shown in class diagram Figure 1.1.
             */
            public double fees, payment;
            public string results, studentType, studentName;
            public int average, studentNumber;

            //Properties
            public double Fees { get { return fees; } set { fees = value; } }
            public double Payment { get { return payment; } set { payment = value; } }
            public string Results { get { return results; } set { results = value; } }
            public string StudentType { get { return studentType; } set { studentType = value; } }
            public string StudentName { get { return studentName; } set { studentName = value; } }
            public int Average { get { return average; } set { average = value; } }
            public int StudentNumber { get { return studentNumber; } set { studentNumber = value; } }

            //Constructor
            public Students(int _studentNumber, string _studentName, string _studentType, int _average, string _results, double _fees, double _payment )
            {
                this.studentNumber = _studentNumber;
                this.studentName = _studentName;
                this.StudentType = _studentType;
                this.average = _average;
                this.results = _results;
                this.fees = _fees;
                this.payment = _payment;
            }

            //Method to override
            public virtual void CalculatePayment()
            {

            }

            /*Inherit a built-in interface and implement a method that will sort students according to
              their names if any names are the same, then sort according to their average mark.*/
            public void Sort()
            {

            }
        }

        //Derived Class
        public class PartTime : Students
        {
            //Constructor
            public PartTime(int _studentNumber, string _studentName, string _studentType, int _average, string _results, double _fees, double _payment) : base(_studentNumber, _studentName, _studentType, _average, _results, _fees, _payment)
            {
            }

            //discount
            public override void CalculatePayment()
            {
                payment = fees - (fees * 0.1);
            }
        }

        //Derived Class
        public class FullTime : Students
        {
            //Constructor
            public FullTime(int _studentNumber, string _studentName, string _studentType, int _average, string _results, double _fees, double _payment) : base(_studentNumber, _studentName, _studentType, _average, _results, _fees, _payment)
            {
            }

            //discount
            public override void CalculatePayment()
            {
                payment = fees - (fees * 0.15);
            }
        }

        private void btnPartTime_Click(object sender, EventArgs e)
        {
            foreach(Students item in allStudents)
            {
                if(item is PartTime)
                {
                    myTable.Rows.Add(allStudents);
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            int input = Convert.ToInt32(txtStudentNumber.Text);
            bool found = false;

            foreach(Students item in myTable.Rows)
            {
                if(item.studentNumber == input)
                {
                    found = true;

                    lblName.Text = item.studentName;
                    lblMark.Text = Convert.ToString(item.average);
                    lblResults.Text = item.results;
                    lblFees.Text = Convert.ToString(item.fees);
                    lblPayment.Text = Convert.ToString(item.payment);
                }
            }

            if(found == false)
            {
                MessageBox.Show("Student not found.");
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            //dataGridView1.Last();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            //dataGridView1.Previous();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            //dataGridView1.Next();
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            //dataGridView1.First();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnFullTime_Click(object sender, EventArgs e)
        {
            foreach (Students item in allStudents)
            {
                if (item is FullTime)
                {
                    myTable.Rows.Add(allStudents);
                }
            }
        }
    }
}
