﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Fuller_Lynnette_PRG2781_CT2
{
    //class for threads for converting video format
    class Conversion
    {
        //method for first message displayed
        public void convertvideo()
        {
            Console.WriteLine("Converting video to MP4 format...");
            Thread.Sleep(5000); //thread waits 5000 milliseconds - 5 seconds
        }

        //method for 2nd message displayed
        public void conversion1()
        {
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("...Please wait: 50% converting...");
            Thread.Sleep(5000); //thread waits 5000 milliseconds - 5 seconds
        }

        //method for 3rd message displayed
        public void conversion2()
        {
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("...Almost done: 97% converting...");
            Thread.Sleep(3000); //thread waits 3000 milliseconds - 3 seconds
        }

        public void conversionFinal()
        {
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("Done Converting");
        }
    }

    class notify //publisher class
    {
        sendEmail email = new sendEmail();
        sendSMS sms = new sendSMS();

        /* CREATE EVENT AND SUBSCRIBE METHODS
         
         event sendEvent = new event(sms.notifyUser());
         sendEvent += email.notifyUser();
             */

        //MAIN METHOD TO INVOKE EVENT
        public void notifyUser()
        {
            /*
            if(sendEvent() != null)
            {
                sendEvent();
            } 
            */

            //NOTIFYING USER USING THREADS 
            Thread t5 = new Thread(sms.notifyUser);
            Thread t6 = new Thread(email.notifyUser);

            t5.Start();
            t5.Join();

            t6.Start();
        }
    }

    class sendSMS   //subscriber class
    {
        public void notifyUser()
        {
            Console.WriteLine();
            Console.WriteLine("Sending SMS to user...");
            Thread.Sleep(5000);
            Console.WriteLine("SMS sent!");
        }
    }

    class sendEmail //subscriber class
    {
        public void notifyUser()
        {
            Console.WriteLine();
            Console.WriteLine("Sending Email to user...");
            Thread.Sleep(5000);
            Console.WriteLine("Email sent!");
        }
    }

    class Program
    {
        //method to convert video
        static void convertVideo()
        {
            Conversion convert = new Conversion();          //initialization of class for threads

            Thread t1 = new Thread(convert.convertvideo);   //First thread to display message
            Thread t2 = new Thread(convert.conversion1);    //Second thread to display message    
            Thread t3 = new Thread(convert.conversion2);    //Third thread to display message
            Thread t4 = new Thread(convert.conversionFinal);    //Fourth thread to display message

            t1.Start();
            t1.Join();      //t2 starts once t1 has finished

            t2.Start();
            t2.Join();      //t3 starts once t2 has finished

            t3.Start();
            t3.Join();      //t4 starts once t3 has finished

            t4.Start();
        }

        //DECLARE DELEGATE
        //static Delegate del;
        
        static void Main(string[] args)
        {
            convertVideo();

            notify n = new notify();
            //del(n.notifyUser());

            n.notifyUser();

            Console.ReadKey();
        }
    }
}
