﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lynnette_Fuller_PRG2781_CT1
{
    abstract class Shape
    {
        //Fields
        private double area, baseValue, height;
        
        public Shape(double bv, double h)
        {
            
            this.baseValue = bv;
            this.height = h;
        }

        //Properties - area
        public double Area
        {
            get { return area; }
            set { area = value; }
        }

        //Properties - baseValue
        public double BaseValue
        {
            get { return baseValue; }
            set { baseValue = value; }
        }

        //Properties - height
        public double Height
        {
            get { return height; }
            set { height = value; }
        }
    }

    class Circle : Shape
    {
        //field
        private double pi = 22/7; //given value of pi

        //properties - pi
        public double Pi
        {
            get { return pi; }
            set { pi = value; }
        }

        //method - constructor
        public Circle(double bv, double h) : base(bv, h) { }

        //method - captureDetails
        public void CaptureDetails()
        {
            Console.WriteLine("Enter Circle Diameter: "); //diameter counts as base, and x2 radius
            BaseValue = Convert.ToDouble(Console.ReadLine());
            
        }

        //method - calculateArea
        public void CalculateArea()
        {
            Area = Pi * BaseValue;
        }

        //method - PrintDetails
        public void PrintDetails()
        {
            Console.WriteLine("");
            Console.WriteLine($"Area of: Circle is {Area}");
        }

        /*Overriding ToString()

        public override string ToString()
        {
            string s = $"Area of: Circle is {Area}";
            return s;
        } */
    }

    class Triangle : Shape
    {
        //method - constructor
        public Triangle(double bv, double h) : base(bv, h) { }

        //method - captureDetails
        public void CaptureDetails()
        {
            Console.WriteLine("Enter Height: ");
            Height = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Base: ");
            BaseValue = Convert.ToDouble(Console.ReadLine());
        }

        //method - calculateArea
        public void CalculateArea()
        {
            Area = (0.5 * BaseValue) * Height;
        }

        //method - PrintDetails 
        public void PrintDetails()
        {
            Console.WriteLine("");
            Console.WriteLine($"Area of: Triangle is {Area}");
        }

        /*Overriding ToString()
         
        public override string ToString()
        {
            string s = $"Area of: Triangle is {Area}";
            return s;
        } */
    }

    class Rectangle : Shape
    {
        //method - constructor
        public Rectangle(double bv, double h) : base(bv, h) { }

        //method - captureDetails
        public void CaptureDetails()
        {
            Console.WriteLine("Enter Height: ");
            Height = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Base: ");
            BaseValue = Convert.ToDouble(Console.ReadLine());
        }

        //method - calculateArea
        public void CalculateArea()
        {
            Area = BaseValue * Height;
        }

        //method - PrintDetails
        public void PrintDetails()
        {
            Console.WriteLine("");
            Console.WriteLine($"Area of: Rectangle is {Area}");
        }

        /*Overriding ToString()

        public override string ToString()
        {
            string s = $"Area of: Triangle is {Area}";
            return s;
        } */
    }

    class Program
    {
        //NOTE Please Use comma's to show decimal values//

        enum mainmenu
        {
            Rectangle = 1,
            Triangle = 2,
            Circle = 3,
            Exit = 4
        }

        public static void main() //This is the method that will run the enum continuously 
        {
            Console.Clear();
            Console.WriteLine("CALCULATE AREA\n");
            Console.WriteLine("1.....Rectangle\n\n2.....Triangle\n\n3.....Circle\n\n4.....Exit");
            Console.Write("\nSelect Your Choice: ");
            string option = Console.ReadLine();

            if (Enum.TryParse(option, out mainmenu menu))
            {
                switch (menu)
                {
                    //Option 1 - Calculate Area of Rectangle
                    case mainmenu.Rectangle:
                        Console.Clear();

                        //declaring and initializing object
                        Rectangle rectangle = new Rectangle(0, 0);  //0,0 because there are no inputted values

                        //methods
                        rectangle.CaptureDetails();
                        rectangle.CalculateArea();
                        rectangle.PrintDetails();

                        Console.ReadKey();
                        break;

                    //Option 2 - Calculate Area of Triangle
                    case mainmenu.Triangle:
                        Console.Clear();

                        //declaring and initializing object
                        Triangle triangle = new Triangle(0, 0);     //0,0 because there are no inputted values

                        //methods
                        triangle.CaptureDetails();
                        triangle.CalculateArea();
                        triangle.PrintDetails();

                        Console.ReadKey();
                        break;

                    //Option 3 - Calculate Area of Circle
                    case mainmenu.Circle:
                        Console.Clear();

                        //declaring and initializing object
                        Circle circle = new Circle(0, 0);           //0,0 because there are no inputted values

                        //Methods
                        circle.CaptureDetails();
                        circle.CalculateArea();
                        circle.PrintDetails();

                        Console.ReadKey();
                        break;

                    //Option 4 - Exit Program
                    case mainmenu.Exit:
                        Environment.Exit(0);
                        break;
                }
            }
        }

        static void Main(string[] args)
        {
            /*By creating the method main(), the program is able to 
             * continuously loop through the main menu until the user wishes to 
             * close the application*/

            do { main(); } while (true);
        }
    }
}
