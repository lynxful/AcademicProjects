﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniqueBuildingServicesLoanCompany
{
    //Declaring the loan constants that are globally declared
    public class LoanConstants
    {
        public static int ShortTerm { get { return 1; } }
        public static int MediumTerm { get { return 3; } }
        public static int LongTerm { get { return 5; } }
        public static double MaxLoanAmount { get { return 100000; } }
    }

    //Declaring user inputs for the loans in a abstract class
    public abstract class Loan
    {
        protected int loanNumber;
        protected string lastName;
        protected string firstName;
        protected double loanAmount;
        protected double interestRate;
        protected int term;


        //Declaring user input details in variables
        public Loan(int loanNumber, string lastName, string firstName, double loanAmount, int term)
        {
            this.loanNumber = loanNumber;
            this.lastName = lastName;
            this.firstName = firstName;
            this.loanAmount = loanAmount > LoanConstants.MaxLoanAmount ? LoanConstants.MaxLoanAmount : loanAmount;
            this.term = IsValidTerm(term) ? term : LoanConstants.ShortTerm;
        }

        public abstract double CalculateTotalAmount();

        //displaying the user inputs
        public override string ToString()
        {
            return $"Loan Number: {loanNumber}" +
                $"\nCustomer: {firstName} {lastName}" +
                $"\nLoan Amount: R{loanAmount}" +
                $"\nInterest Rate: {interestRate * 100}%" +
                $"\nTerm: {term} years\nTotal " +
                $"Amount Owed: R{CalculateTotalAmount()}";
        }

        protected bool IsValidTerm(int term)
        {
            return term == LoanConstants.ShortTerm || term == LoanConstants.MediumTerm || term == LoanConstants.LongTerm;
        }
    }

    //Creating a public class for the business loan which inherits from the loan class
    public class BusinessLoan : Loan
    {
        //declaring businessloan and its variables
        public BusinessLoan(int loanNumber, string lastName, string firstName, double loanAmount, int term, double primeInterestRate)
            : base(loanNumber, lastName, firstName, loanAmount, term)
        {
            //doing the calculations
            interestRate = primeInterestRate / 100 + 0.01;
        }

        public override double CalculateTotalAmount()
        {
            //calculating the total ammount
            return loanAmount + loanAmount * interestRate;
        }
    }
    //Declaring the personal laon class that inherits properties of the loan class
    public class PersonalLoan : Loan
    {
        public PersonalLoan(int loanNumber, string lastName, string firstName, double loanAmount, int term, double primeInterestRate)
            : base(loanNumber, lastName, firstName, loanAmount, term)
        {
            //calculating the personal loan numbers
            interestRate = primeInterestRate / 100 + 0.02;
        }

        public override double CalculateTotalAmount()
        {
            //calculating the total ammount for the personal loan
            return loanAmount + loanAmount * interestRate;
        }
    }

    class Program
    {
        //Doing the interface and displaying all the data
        static void Main(string[] args)
        {
            LoanConstants loanConstants = new LoanConstants();


            Console.Write("Enter the current prime interest rate: ");
            double primeInterestRate = Convert.ToDouble(Console.ReadLine());

            Loan[] loans = new Loan[5];

            for (int i = 0; i < 5; i++)
            {
                //Doing the interface:
                Console.WriteLine("------------------------------");
                Console.Write("Enter loan type (Business/Personal): ");
                string loanType = Console.ReadLine();

                Console.WriteLine("------------------------------");
                Console.Write("Enter loan number: ");
                int loanNumber = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("------------------------------");
                Console.Write("Enter customer last name: ");
                string lastName = Console.ReadLine();

                Console.WriteLine("------------------------------");
                Console.Write("Enter customer first name: ");
                string firstName = Console.ReadLine();

                Console.WriteLine("------------------------------");
                Console.Write("Enter loan amount: ");
                double loanAmount = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("------------------------------");
                Console.Write("Enter loan term (1/3/5 years): ");
                int term = Convert.ToInt32(Console.ReadLine());

                //displaying the business loan or personal loan depending on the users input 
                if (loanType.ToLower() == "business")
                {
                    loans[i] = new BusinessLoan(loanNumber, lastName, firstName, loanAmount, term, primeInterestRate);
                }
                else if (loanType.ToLower() == "personal")
                {
                    loans[i] = new PersonalLoan(loanNumber, lastName, firstName, loanAmount, term, primeInterestRate);
                }
                else
                {
                    //displaying a error message if the user does not input the right loan type
                    Console.WriteLine("Invalid loan type. Defaulting to Personal Loan.");
                    loans[i] = new PersonalLoan(loanNumber, lastName, firstName, loanAmount, term, primeInterestRate);
                }

                Console.Clear();
            }

            Console.WriteLine("\nLoan Information:\n");

            //making the program look nicer
            foreach (Loan loan in loans)
            {
                if (loan != null)
                {
                    Console.WriteLine(loan);
                    Console.WriteLine("-------------------------");
                }
            }
            Console.ReadKey();
        }
    }
}
