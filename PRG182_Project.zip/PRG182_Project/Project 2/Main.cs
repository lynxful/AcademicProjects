﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    enum mainMenu { 
        one, two, three, four, five, six
    }
    enum breakfastMenu
    {
        one, two, three, four
    }
    enum comboMenu
    {
        one, two, three, four
    }
    enum burgerMenu
    {
        one, two, three, four
    }
    enum drankMenu
    {
        one, two, three, four
    }

    internal class Items
    {
        public static List<Food_Items> arr = new List<Food_Items>();
        public static List<int> order = new List<int>();
        public static void Main(String[] args)
        {
            populate(); //assigns values to variables

            do{
                main();
            } while (true); //application loops until console exited
        }

        public static void main()
        {
            Console.Clear();
            Console.WriteLine("Please select an option:" +
                "\none for breakfast" +
                "\ntwo for burgers" +
                "\nthree for drinks" +
                "\nfour for combos" +
                "\nfive to checkout" +
                "\nsix to close the application");
            String option = Console.ReadLine();

            if (Enum.TryParse(option, out mainMenu menu)) //selects menu according to user input
            {
                switch (menu)
                {
                    case mainMenu.one:
                        Console.Clear();
                        breakfast();
                        break;
                    case mainMenu.two:
                        Console.Clear();
                        burgers();
                        break;
                    case mainMenu.three:
                        Console.Clear();
                        drinks();
                        break;
                    case mainMenu.four:
                        Console.Clear();
                        combos();
                        break;
                    case mainMenu.five:
                        Console.Clear();
                        printOrder();
                        break;
                    case mainMenu.six:
                        Environment.Exit(0);
                        break;
                }
            }
        }
        public static void populate()
        {
            Food_Items item = new Food_Items("Hash Brown", 59.99);
            arr.Add(item);
            item = new Food_Items("Pancakes", 40.99);
            arr.Add(item);
            item = new Food_Items("French Toast", 69.99);
            arr.Add(item);
            item = new Food_Items("Beef Burger", 79.99);
            arr.Add(item);
            item = new Food_Items("Chicken Burger", 79.99);
            arr.Add(item);
            item = new Food_Items("Veggie Burger", 79.99);
            arr.Add(item);
            item = new Food_Items("Coke", 9.99);
            arr.Add(item);
            item = new Food_Items("Cream Soda", 9.99);
            arr.Add(item);
            item = new Food_Items("Water", 5.99);
            arr.Add(item);
        }
        public static bool breakfast()
        {
            Console.WriteLine("Please select an option\none for Hash Brown\ntwo for Pancakes\nthree for French Toast\nfour to go back");
            String option = Console.ReadLine();

            if (Enum.TryParse(option, out breakfastMenu menu))
            {
                switch (menu)
                {
                    case breakfastMenu.one:
                        order.Add(0); //adds to order list
                        break;
                    case breakfastMenu.two:
                        order.Add(1);
                        break;
                    case breakfastMenu.three:
                        order.Add(2);
                        break;
                    case breakfastMenu.four:
                        break;
                    default:
                        Console.WriteLine("invalid option");
                        break;
                }
            }
            return false;
        }
        public static bool burgers()
        {
            Console.WriteLine("Please select an option\none for Beef Burger\ntwo for Chicken Burger\nthree for Veggie Burger\nfour to go back");
            String option = Console.ReadLine();

            if (Enum.TryParse(option, out burgerMenu menu)) //enum.TryParse(<input>,<output>)
            {
                switch (menu)
                {
                    case burgerMenu.one:
                        order.Add(3);
                        break;
                    case burgerMenu.two:
                        order.Add(4);
                        break;
                    case burgerMenu.three:
                        order.Add(5);
                        break;
                    case burgerMenu.four:
                        break;
                    default:
                        Console.WriteLine("invalid option");
                        break;
                }
            }
            return false;
        }
        public static bool drinks()
        {
            Console.WriteLine("Please select an option\none for Coke\ntwo for Cream Soda\nthree for Water\nfour to go back");
            String option = Console.ReadLine();

            if (Enum.TryParse(option, out drankMenu menu))
            {
                switch (menu)
                {
                    case drankMenu.one:
                        order.Add(6);
                        break;
                    case drankMenu.two:
                        order.Add(7);
                        break;
                    case drankMenu.three:
                        order.Add(8);
                        break;
                    case drankMenu.four:
                        break;
                    default:
                        Console.WriteLine("invalid option");
                        break;
                }
            }
            return false;
        }
        public static bool combos()
        {
            Console.WriteLine("Please select an option\none for Beef burger and buddy\ntwo for Chicken Burger and buddy\nthree for Veggie Burger and buddy\nfour to go back");
            String option = Console.ReadLine();

            if (Enum.TryParse(option, out comboMenu menu))
            {
                switch (menu)
                {
                    case comboMenu.one:
                        order.Add(3);
                        drinks();
                        break;
                    case comboMenu.two:
                        order.Add(4);
                        drinks();
                        break;
                    case comboMenu.three:
                        order.Add(5);
                        drinks();
                        break;
                    case comboMenu.four:
                        break;
                    default:
                        Console.WriteLine("invalid option");
                        break;
                }
            }
            return true; //returns as true as to give user discount for combo meal
        }
        public static void printOrder()
        {
            double total = 0;
            for (int i = 0; i < order.LongCount(); i++)
            {
                Console.WriteLine(arr[order[i]].getFood());
                total = total + arr[order[i]].getFoodPrice();
            }
            Console.WriteLine("Your total is: " + total);
            Console.WriteLine("press enter to continue");
            order.Clear();
            Console.ReadKey();

        }
    }
}