﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    internal class Food_Items
    {
        private String foodName;
        private double foodPrice;
        
        public Food_Items(String foodName, double foodPrice)
        {
            this.foodName = foodName;
            this.foodPrice = foodPrice;
        }

        public String getFood()
        {
            return this.foodName + " " + this.foodPrice;
        }

        public double getFoodPrice()
        {
            return this.foodPrice;
        }
        public void setFoodName(String foodName)
        {
            this.foodName=foodName;
        }

        public void setFoodPrice(Double foodPrice)
        {
            this.foodPrice=foodPrice;
        }

        
    }
}