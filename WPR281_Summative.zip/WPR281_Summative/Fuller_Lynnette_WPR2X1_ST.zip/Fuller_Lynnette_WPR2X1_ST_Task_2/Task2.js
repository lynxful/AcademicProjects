/*A user should be able to input different temperature values for each day of the week.
Remember that a user may give you a value which is not entirely made of numbers, or they
may input nothing at all. Validate the input from the user in JavaScript.*/

function checkInput(x)
{
    let flag = false;

    for(let i = 0; i < x.length; i++)
    {   
        try 
        {
            let stringTest = parseInt(document.getElementById(x[i]));
            flag = false;
        } 
        catch (error) 
        {
            alert("Input must be numerical");
            flag = true;
        }

        if(flag == false)
        {
            if(document.getElementById(x[i]) == "")
            {
                alert("input cannot be empty");
                flag = true;
            }
            else
            {
                flag = false;
            }
        }

        if(flag == true){break;} else{continue;}  
    }

    return flag;
}

/*When the user clicks the Display Results button and all input is checked as valid, the app should
first display the entered temperatures for each day, in an ordered list 

The app should then calculate the average temperature for the week and display*/

function getValues()
{
    let monInput = document.getElementById("temp1");
    let tuesInput = document.getElementById("temp2");
    let wedInput = document.getElementById("temp3");
    let thursInput = document.getElementById("temp4");
    let friInput = document.getElementById("temp5")    

    let arrInput = [];
    arrInput.push(monInput);
    arrInput.push(tuesInput);
    arrInput.push(wedInput);
    arrInput.push(thursInput);
    arrInput.push(friInput);

    return arrInput;
}

function calculateAverage(x)
{
    let sum = 0;
    for(let i = 0; i < x.length; i++)
    {
        sum += x[i];
    }

    let average = sum / x.length;
    return average;
}

function displayResults()
{
    let arrInput = getValues();    

    if(checkInput(arrInput) == true)
    {
        console.log("There are errors")
    } 
    else 
    {
        let average = calculateAverage(arrInput);
        let min = Math.min(arrInput);
        let max = Math.max(arrInput);
        
        let temps = "Entered Temperatures: \n" + 
                "1. Monday: " + arrInput[0] + "\n" +
                "2. Tuesday: " + arrInput[1] +"\n" +
                "3. Wednesday: " + arrInput[2] + "\n" +
                "4. Thursday: " + arrInput[3] +"\n" +
                "5. Friday: " + arrInput[4] + "\n"; 

        let minmax = "Minimum and Maximum Temperatures: \n" +
                "Minimum: " + min + "\n" +
                "Maximum: " + max + "\n";

        let averageTemp = "Average Temperature: \n" + average + "\n";

        document.getElementById("temperatures").append(temps);
        document.getElementById("minmaxtemp").append(minmax);
        document.getElementById("averagetemp").append(averageTemp); 
    }
    
    
}
