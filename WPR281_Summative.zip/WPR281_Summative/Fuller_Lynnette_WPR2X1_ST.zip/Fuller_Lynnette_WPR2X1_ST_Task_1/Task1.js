const pizzaRestaurants = [
    {
        name: "Pronto Pizza", rating: 4.7, text: ""
    },
    {
        name: "Frankies Pizza", rating: 3.5, text: ""
    },
    {
        name: "Diamond Slice", rating: 4.2, text: ""
    },
    {
        name: "Grand Torino Pizza", rating: 3.7, text: ""
    },
    {
        name: "Azzuri Pizza", rating: 4.8, text: ""
    },
    {
        name: "St Anna Pizza", rating: 2.7, text: ""
    }
];

/*Part a - Transform the array using an array transformation method. If the rating of each restaurant is
above 4, set text to Highly Rated. If the rating of each restaurant if below 4, set text to Low
Rated*/

let transformedArray = [];
transformedArray = pizzaRestaurants.copyWithin();       //creates a copy of the original array to be transformed

for(let i = 0; i < transformedArray.length; i++)
{
    if(transformedArray[i].rating > 4){
        transformedArray[i].text = "Highly rated"
    }
    else 
    {
        transformedArray[i].text = "Low rated"
    }  
}

/*Part b - Use a loop of your choice to display the transformed array*/

console.log("Transformed Array:");

for(let i = 0; i < transformedArray.length; i++)
{
    console.log(transformedArray[i].name + " is " + transformedArray[i].text + " at: " + transformedArray[i].rating);
}

/*Part c - Use an array transformation method to go through the transformedArray, and return the
average rating*/

let averageRating = 0;

for(let i = 0; i < transformedArray.length; i++){
    averageRating += transformedArray[i].rating;
}

averageRating = averageRating / transformedArray.length;

//Part d - Display

console.log("Average Rating: " + averageRating);

/*Part e - Use an array transformation method to go through the transformedArray, return a new
array, which uses a loop to display only the Highly Rated restaurants, as follows:*/

let highRatedArray = [];

for(let i = 0; i < transformedArray.length; i++){
    if(transformedArray[i].text == "Highly rated"){
        highRatedArray.push(transformedArray[i]);
    }
}

console.log("Highly Rated Restuarants: ")
for(let i = 0; i < highRatedArray.length; i++)
{
    console.log(highRatedArray[i].name + " is " + highRatedArray[i].text + " at: " + highRatedArray[i].rating);
}

