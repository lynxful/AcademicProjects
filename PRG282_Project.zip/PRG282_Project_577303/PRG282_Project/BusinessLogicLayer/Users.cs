﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//namespace
using PRG282_Project.DataLayer;

namespace PRG282_Project.BusinessLogicLayer
{
    internal class Users
    {
        //Create instance of file handler class
        FileHandler handler = new FileHandler();
        

        public void CheckUser(string username, string password) 
        { 
            //gets list of existing users
            List<login> users = new List<login>();
            users = handler.GetLogins();

            try
            {
                //checks if user exists

            }
            catch (Exception)
            {
                //user does not exist
                MessageBox.Show("Error -  user does not exist.");
            }
        }

        public void CreateUser(string username, string password) 
        {
            try
            {
                //create new user
                handler.WriteLoginDetails(username, password);
            }
            catch (Exception)
            {
                //unable to create new user
                MessageBox.Show("Error - unable to create new user");
            }
        }   
    }
}
