﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PRG282_Project.DataLayer;
using PRG282_Project.BusinessLogicLayer;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection;

namespace PRG282_Project
{
    public partial class MainForm : Form
    {
        Datahandler handler = new Datahandler();
        private object textbox1;

        public MainForm()
        {
            InitializeComponent();
        }

        private void txtaddress_Click(object sender, EventArgs e)
        {
        }

        private void btnExit2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            handler.UpdateStudent(int.Parse(stdNumber.Text), txtName.Text,txtSurname.Text,gender.Text,txtPhone.Text, txtMdlCode.Text);
            string getstudents = @"SELECT * FROM Studentz";
            dataGridView1.DataSource = handler.readData(getstudents);

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }

        private void ListView1(object sender, MouseEventArgs e)
        {
        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
        
            

          
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            handler.DeleteStudent(int.Parse(stdNumber.Text));
            string getstudents = @"SELECT * FROM Studentz";
            dataGridView1.DataSource = handler.readData(getstudents);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            RegisterForm registerForm = new RegisterForm();
            registerForm.ShowDialog();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != 0)
            {
                DataGridViewRow dvgRow = dataGridView1.Rows[e.RowIndex];
                stdNumber.Text = dvgRow.Cells[0].Value.ToString();
                txtName.Text = dvgRow.Cells[1].Value.ToString();
                txtSurname.Text = dvgRow.Cells[2].Value.ToString();
                gender.Text= dvgRow.Cells[4].Value.ToString();
                txtPhone.Text = dvgRow.Cells[5].Value.ToString();
                txtMdlCode.Text = dvgRow.Cells[7].Value.ToString();

            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            string getstudents = @"SELECT * FROM Studentz";
            dataGridView1.DataSource=handler.readData(getstudents);
            handler.getModules(txtMdlCode);
        }

        private void txtMdlCode_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
