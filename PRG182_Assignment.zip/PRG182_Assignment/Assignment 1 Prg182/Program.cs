﻿using System;

namespace Assignment_1_Prg182
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("------------------");
            Console.WriteLine("Sorting");
            Console.WriteLine("1.Bubble sort");
            Console.WriteLine("2.Quicksort");
            Console.WriteLine("3.Merge sort");
            Console.WriteLine("------------------");
            Console.WriteLine("Please select the number from the sorting method that you want.");

            int num1 = Convert.ToInt32(Console.ReadLine());

            if (num1 == 1)
            {
                Console.WriteLine("------------------");
                Console.WriteLine("Searching method");
                Console.WriteLine("1.Linear search");
                Console.WriteLine("2.Binary seach");
                Console.WriteLine("------------------");
                Console.WriteLine("Please select the number from the searching method that you want.");

                int num2 = Convert.ToInt32(Console.ReadLine());

                if (num2 == 1)
                {
                
                    BubblesortLin();
                }

                if(num2 == 2)
                {
                   
                    BubblesortBin();
                }
            }

            if (num1 == 2)
            {
                Console.WriteLine("------------------");
                Console.WriteLine("Searching method");
                Console.WriteLine("1.Linear search");
                Console.WriteLine("2.Binary seach");
                Console.WriteLine("------------------");
                Console.WriteLine("Please select the number from the method that you want.");

                int num2 = Convert.ToInt32(Console.ReadLine());

                if (num2 == 1)
                {
                   
                    QuicksortLin();
                }

                if(num2 == 2)
                {
                    
                    QuicksortBin();
                }
            }

            if (num1 == 3)
            {
                Console.WriteLine("------------------");
                Console.WriteLine("Searching method");
                Console.WriteLine("1.Linear search");
                Console.WriteLine("2.Binary seach");
                Console.WriteLine("------------------");
                Console.WriteLine("Please select the number from the method that you want.");

                int num2 = Convert.ToInt32(Console.ReadLine());

                if (num2 == 1)
                {
                   
                    MergesortLin();
                }

                if(num2 == 2)
                {
                  
                    MergesortBin();
                }
            }

            Console.ReadKey();

        }

        public static void BubblesortLin()
        {
         Console.WriteLine("------------------");
         Console.WriteLine("Please enter array size");
            Console.WriteLine("------------------");
            int a = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[a];
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter array values.");
            Console.WriteLine("------------------");
            for (int b = 0; b <= a - 1; b++)
            {
                int c = Convert.ToInt32(Console.ReadLine());

                array[b] = c;

            }
            Console.WriteLine("Your array is :");
            Display(array);
            
            int temp = 0;
            Console.WriteLine("------------------");
            Console.WriteLine("Your array after bubble sort:");
            for (int z =0; z<array.Length;z++)
            {
             for (int x = 0; x< array.Length; x++)
             {
                    if(array[z]< array[x]) 
                    {
                        temp = array[z];
                        array[z] = array[x];
                        array[x] = temp;
                    }
             }         
            }
            
            Display(array);
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter the value you would like to search for.");
            int value = int.Parse(Console.ReadLine());
            int index = LinearSearch(array, value);
            Console.WriteLine("------------------");
            if (index < 0)
            {
                Console.WriteLine($"{value} was not be found.");
            }
            else
            {
                Console.WriteLine($"{value} was found at index : {index} ");
            }

        }
        
        
        public static void QuicksortLin()
        {
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter array size");
            Console.WriteLine("------------------");
            int a = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[a];
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter array values.");
            Console.WriteLine("------------------");
            for (int b = 0; b <= a - 1; b++)
            {
                int c = Convert.ToInt32(Console.ReadLine());

                array[b] = c;

            }
            Console.WriteLine("Your array is :");
            Display(array);

            Console.WriteLine("Your array after quick sort. ");
            Quicksort(array, 0, array.Length - 1);
            Display(array);
       
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter the value you would like to search for.");
            int value = int.Parse(Console.ReadLine());
            int index = LinearSearch(array, value);
            Console.WriteLine("------------------");
            if (index < 0)
            {
                Console.WriteLine($"{value} was not be found.");
            }
            else
            {
                Console.WriteLine($"{value} was found at index : {index} ");
            }


        }

        public static void MergesortLin()
        {
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter array size");
            Console.WriteLine("------------------");
            int a = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[a];
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter array values.");
            Console.WriteLine("------------------");
            for (int b = 0; b <= a - 1; b++)
            {
                int c = Convert.ToInt32(Console.ReadLine());

                array[b] = c;

            }
            Console.WriteLine("Your array is :");
            Display(array);
            
            Mergesort(array);
            Console.WriteLine("------------------");
            Console.WriteLine("Your array after merge sort :");
            Display(array);
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter the value you would like to search for.");
            int value = int.Parse(Console.ReadLine());
            int index = LinearSearch(array, value);
            Console.WriteLine("------------------");
            if (index < 0)
            {
                Console.WriteLine($"{value} was not found.");
            }
            else
            {
                Console.WriteLine($"{value} was found at index : {index} ");
            }

        }

        public static void Mergesort(Span<int> array)
        {
            var center = array.Length / 2;

            if (array.Length>1)
            {
                Mergesort(array.Slice(0, center));
                Mergesort(array.Slice(center));
                Merge(array, center);

            }

        }
        public static void Merge(Span<int> result , int Startofrighthalf)
        {
            var array = result.ToArray();
            var lhs = 0;
            var rhs = Startofrighthalf;
            var offset = 0;

            while (lhs < Startofrighthalf && rhs< array.Length)
            {
                if (array[lhs]<=array[rhs])
                {
                    result[offset] = array[lhs];
                    lhs++;

                }
                else
                {
                    result[offset] = array[rhs];
                    rhs++;

                }
                offset++;

            }

            while(lhs <  Startofrighthalf)
            {
                result[offset] = array[lhs];
                lhs++;
                offset++;

            }
            while(rhs < array.Length)
            {
                result[offset] = array[rhs];
                rhs++;
                offset++;

            }



        }




        public static void BubblesortBin()
        {
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter array size");
            Console.WriteLine("------------------");
            int a = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[a];
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter array values.");
            Console.WriteLine("------------------");
            for (int b = 0; b <= a - 1; b++)
            {
                int c = Convert.ToInt32(Console.ReadLine());

                array[b] = c;

            }
            Console.WriteLine("Your array is :");
            Display(array);
            
            int temp = 0;
            Console.WriteLine("------------------");
            Console.WriteLine("Your array after bubble sort:");
            for (int z = 0; z < array.Length; z++)
            {
                for (int x = 0; x < array.Length; x++)
                {
                    if (array[z] < array[x])
                    {
                        temp = array[z];
                        array[z] = array[x];
                        array[x] = temp;
                    }
                }
            }
            Display(array);
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter the value you would like to search for.");
            int value = int.Parse(Console.ReadLine());
           int result = BinarySearch(array, value);
            Console.WriteLine("------------------");
            if (result < 0)
            {
                Console.WriteLine($"{value} was not found");
            }
            else
            {
                Console.WriteLine($"{value} is found at index : {result}");
            }
        }
       
        public static void QuicksortBin()
        {
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter array size");
            Console.WriteLine("------------------");
            int a = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[a];
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter array values.");
            Console.WriteLine("------------------");
            for (int b = 0; b <= a - 1; b++)
            {
                int c = Convert.ToInt32(Console.ReadLine());

                array[b] = c;

            }
            Console.WriteLine("Your array is :");
            Display(array);
           
            Console.WriteLine("Your array after quick sort. ");
            Quicksort(array, 0, array.Length - 1);
            Display(array);
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter the value you would like to search for.");
            int value = int.Parse(Console.ReadLine());
            int result = BinarySearch(array, value);
            Console.WriteLine("------------------");
            if (result < 0)
            {
                Console.WriteLine($"{value} was not found");
            }
            else
            {
                Console.WriteLine($"{value} is found at index : {result}");
            }


        }

        public static void MergesortBin()
        {
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter array size");
            Console.WriteLine("------------------");
            int a = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[a];
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter array values.");
            Console.WriteLine("------------------");
            for (int b = 0; b <= a - 1; b++)
            {
                int c = Convert.ToInt32(Console.ReadLine());

                array[b] = c;

            }
            Console.WriteLine("Your array is :");
            Display(array);
            Mergesort(array);
            Console.WriteLine("------------------");
            Console.WriteLine("Your array after merge sort :");
            Display(array);
            Console.WriteLine("------------------");
            Console.WriteLine("Please enter the value you would like to search for.");
            int value = int.Parse(Console.ReadLine());
            int result = BinarySearch(array, value);
            Console.WriteLine("------------------");
            if (result < 0)
            {
                Console.WriteLine($"{value} was not found");
            }
            else
            {
                Console.WriteLine($"{value} is found at index : {result}");
            }



        }
        public static void Display(int[] array)
        {
            var text = string.Join(',', array);
            Console.WriteLine(text);

        }
         
        public static int LinearSearch(int[] array, int x)
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i]==x)
                {
                    return i;
                }

            }
            return -1;

        }
        public static int BinarySearch(int[] array , int value )
        {
            int start = 0;
            int end = array.Length - 1;
            while (start <= end)
            {
                int mid = (start + end) / 2;
                if (value == array[mid])
                {
                    return mid;
                }
                else if (value < array[mid])
                {
                    end = mid - 1;

                }
                else
                {
                    start = mid + 1;

                }
            }
            return -1;
        }
        public static void Quicksort(int[]array , int start , int end)
        {
            if (end <= start) return;
            int pivot = Partition(array, start, end);
            Quicksort(array, start, pivot - 1);
            Quicksort(array, pivot + 1, end);
        }
        public static int Partition(int[] array , int start , int end)
        {
            int pivot = array[end];
            int i = start - 1; 

            for(int j = start; j<= end-1; j++)
            {
                if (array[j]<pivot)
                {
                    i++;
                    int temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }
            i++;
            int tem = array[i];
            array[i] = array[end];
            array[end] = tem;
            return i;
        }
        

            
    }
}
  

